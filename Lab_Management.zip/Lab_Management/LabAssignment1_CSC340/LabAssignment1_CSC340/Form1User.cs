﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LabAssignment1_CSC340
{
    public partial class Form1User : Form
    {
        public Form1User()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ActiveForm.Visible = false;
            //Lab430.ActiveForm.ShowDialog();
            Lab430User frmsecond = new Lab430User();
            frmsecond.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ActiveForm.Visible = false;
            //Lab430.ActiveForm.ShowDialog();
            Lab444User frmsecond = new Lab444User();
            frmsecond.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ActiveForm.Visible = false;
            //Lab430.ActiveForm.ShowDialog();
            Lab445User frmsecond = new Lab445User();
            frmsecond.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ActiveForm.Visible = false;
            //Lab430.ActiveForm.ShowDialog();
            Lab449User3 frmsecond = new Lab449User3();
            frmsecond.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            ActiveForm.Visible = false;
            //Lab430.ActiveForm.ShowDialog();
            Lab452User frmsecond = new Lab452User();
            frmsecond.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            ActiveForm.Visible = false;
            //Lab430.ActiveForm.ShowDialog();
            Lab455User frmsecond = new Lab455User();
            frmsecond.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            ActiveForm.Visible = false;
            //Lab430.ActiveForm.ShowDialog();
            Lab329User frmsecond = new Lab329User();
            frmsecond.ShowDialog();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            ActiveForm.Visible = false;
            //Lab430.ActiveForm.ShowDialog();
            Lab330User frmsecond = new Lab330User();
            frmsecond.ShowDialog();
        }
    }
}
