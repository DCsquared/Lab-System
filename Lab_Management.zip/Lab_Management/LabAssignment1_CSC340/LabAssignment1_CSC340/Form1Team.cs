﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LabAssignment1_CSC340;

namespace LabAssignment1_CSC340
{
    public partial class Form1Team : Form
    {
        public Form1Team()
        {

            InitializeComponent();

        }


        public void displayLabs()
        {
            //var time = DateTime.Now;
            //System.out.print = time;
            //Lab.retrieveLabStatus();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            ActiveForm.Visible = false;
            //Lab430.ActiveForm.ShowDialog();
            Lab430 frmsecond = new Lab430();
            frmsecond.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ActiveForm.Visible = false;
            //Lab430.ActiveForm.ShowDialog();
            Lab444 frmsecond = new Lab444();
            frmsecond.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ActiveForm.Visible = false;
            //Lab430.ActiveForm.ShowDialog();
            Lab445 frmsecond = new Lab445();
            frmsecond.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ActiveForm.Visible = false;
            //Lab430.ActiveForm.ShowDialog();
            Lab449 frmsecond = new Lab449();
            frmsecond.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            ActiveForm.Visible = false;
            //Lab430.ActiveForm.ShowDialog();
            Lab452 frmsecond = new Lab452();
            frmsecond.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            ActiveForm.Visible = false;
            //Lab430.ActiveForm.ShowDialog();
            Lab455 frmsecond = new Lab455();
            frmsecond.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            ActiveForm.Visible = false;
            //Lab430.ActiveForm.ShowDialog();
            Lab329 frmsecond = new Lab329();
            frmsecond.ShowDialog();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            ActiveForm.Visible = false;
            //Lab430.ActiveForm.ShowDialog();
            Lab330 frmsecond = new Lab330();
            frmsecond.ShowDialog();
        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }

}
